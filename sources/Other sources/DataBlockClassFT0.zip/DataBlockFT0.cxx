

#include "DataBlockFT0.h"

using namespace std;
using std::cout;
using std::endl;

ClassImp(DataBlockFT0)

DataBlockFT0::DataBlockFT0(){
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Initializating object DataBlockFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";

	cout<<"\n/Initialization complete!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";

}
/*******************************************************************************************************************/


/*******************************************************************************************************************/
void DataBlockFT0::GenerateData()	{
	for(int iCh=0;iCh<2*fEventHeader.Nwords;iCh++)	{
		fEventDataFT0[iCh].channelID=iCh;
		fEventDataFT0[iCh].charge = 1000;
		fEventDataFT0[iCh].time = 500;
		fEventDataFT0[iCh].is1TimeLostEvent=1;
		fEventDataFT0[iCh].is2TimeLostEvent=1;
		fEventDataFT0[iCh].isADCinGate=1;
		fEventDataFT0[iCh].isAmpHigh=1;
		fEventDataFT0[iCh].isDoubleEvent=1;
		fEventDataFT0[iCh].isEventInTVDC=1;
		fEventDataFT0[iCh].isTimeInfoLate=1;
		fEventDataFT0[iCh].isTimeInfoLost=1;
		fEventDataFT0[iCh].numberADC=1;
	}
}
/*******************************************************************************************************************/
void DataBlockFT0::GenerateHeader(Int_t nWords)	{
	fEventHeader.startDescriptor = gStartDescriptor;
	fEventHeader.Nwords = nWords;
	fEventHeader.reservedField = 0;
	fEventHeader.bc=200;
	fEventHeader.orbit=100;
}
/*******************************************************************************************************************/
void DataBlockFT0::GenerateRandomHeader()	{
	fEventHeader.startDescriptor = gStartDescriptor;
	fEventHeader.Nwords = std::rand()%7;
	fEventHeader.bc = std::rand()%2000; // 1999-max bc
	fEventHeader.orbit = std::rand()%100;
}
/*******************************************************************************************************************/
void DataBlockFT0::GenerateRandomData()	{
	fIsHalfWord = std::rand()%2;
	for(int iCh=0;iCh<2*fEventHeader.Nwords;iCh++)	{
		fEventDataFT0[iCh].channelID=std::rand()%208+1;
		fEventDataFT0[iCh].charge = std::rand()%1000;
		fEventDataFT0[iCh].time = std::rand()%500;
		fEventDataFT0[iCh].is1TimeLostEvent=std::rand()%2;
		fEventDataFT0[iCh].is2TimeLostEvent=std::rand()%2;
		fEventDataFT0[iCh].isADCinGate=std::rand()%2;
		fEventDataFT0[iCh].isAmpHigh=std::rand()%2;
		fEventDataFT0[iCh].isDoubleEvent=std::rand()%2;
		fEventDataFT0[iCh].isEventInTVDC=std::rand()%2;
		fEventDataFT0[iCh].isTimeInfoLate=std::rand()%2;
		fEventDataFT0[iCh].isTimeInfoLost=std::rand()%2;
		fEventDataFT0[iCh].numberADC=std::rand()%2;
	}
	if(fIsHalfWord)	fEventDataFT0[2*fEventHeader.Nwords-1].channelID = 0;
}
/*******************************************************************************************************************/
void DataBlockFT0::GenerateRandomEvent()	{
	GenerateRandomHeader();
	GenerateRandomData();
}
/*******************************************************************************************************************/
void DataBlockFT0::Print(bool doPrintData)	{
	cout<<endl<<"==================Raw event data=================="<<endl;
	cout<<"##################Header##################"<<endl;
	cout<<"startDescriptor: "<<fEventHeader.startDescriptor<<endl;
	cout<<"Nwords: "<<fEventHeader.Nwords<<endl;
	cout<<"BC: "<<fEventHeader.bc<<endl;
	cout<<"Orbit: "<<fEventHeader.orbit<<endl;
	cout<<"##########################################"<<endl;
	if(!doPrintData)	return;
	cout<<"###################DATA###################"<<endl;
	for(int iCh=0;iCh<2*fEventHeader.Nwords;iCh++)	{
		cout<<"------------Channel "<<fEventDataFT0[iCh].channelID<<"------------"<<endl;
		cout<<"Charge: "<<fEventDataFT0[iCh].charge<<endl;
		cout<<"Time: "<<fEventDataFT0[iCh].time<<endl;
		cout<<"1TimeLostEvent: "<<fEventDataFT0[iCh].is1TimeLostEvent<<endl;
		cout<<"2TimeLostEvent: "<<fEventDataFT0[iCh].is2TimeLostEvent<<endl;
		cout<<"ADCinGate: "<<fEventDataFT0[iCh].isADCinGate<<endl;
		cout<<"AmpHigh: "<<fEventDataFT0[iCh].isAmpHigh<<endl;
		cout<<"DoubleEvent: "<<fEventDataFT0[iCh].isDoubleEvent<<endl;
		cout<<"EventInTVDC: "<<fEventDataFT0[iCh].isEventInTVDC<<endl;
		cout<<"TimeInfoLate: "<<fEventDataFT0[iCh].isTimeInfoLate<<endl;
		cout<<"TimeInfoLost: "<<fEventDataFT0[iCh].isTimeInfoLost<<endl;
		cout<<"numberADC: "<<fEventDataFT0[iCh].numberADC<<endl;
	}
	cout<<"##########################################"<<endl;
}
/*******************************************************************************************************************/
DataBlockFT0::~DataBlockFT0()	{
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Deleting object DataBlockFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Deleting completed!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";
}

/*******************************************************************************************************************/

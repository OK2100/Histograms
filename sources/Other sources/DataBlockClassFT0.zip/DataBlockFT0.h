#ifndef DataBlockFT0_cxx
#define DataBlockFT0_cxx
#define NCHANNELS_FIT 208
#define NCHANNELS_PM 12
#define NBITS_EVENTDATA 9
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct EventHeaderFT0	{
	uint64_t startDescriptor:4,
		Nwords:4,
		reservedField:32, ///will be used as event id
		orbit:32,
		bc:12;
	bool isEqualEvent(const EventHeaderFT0 &eventHeader)	{
		if((orbit - eventHeader.orbit)||(bc-eventHeader.bc))	return false;
		return true;
	}
	bool isEqualEvent(const EventHeaderFT0 *eventHeader)	{
		if((orbit - eventHeader->orbit)||(bc-eventHeader->bc))	return false;
		return true;
	}
};
struct EventDataFT0	{
	uint64_t time:12,
		charge:12,
		numberADC:1,
		isDoubleEvent:1,
		is1TimeLostEvent:1,
		is2TimeLostEvent:1,
		isADCinGate:1,
		isTimeInfoLate:1,
		isAmpHigh:1,
		isEventInTVDC:1,
		isTimeInfoLost:1,
		channelID:4; /// equal to zero in case of half-word
};
class DataBlockFT0
{
public:

	DataBlockFT0();
	virtual ~DataBlockFT0();
	void GenerateHeader(Int_t nWords); ///Generate header for nWords (range: 0-4)
	void GenerateData();
	void GenerateRandomHeader();
	void GenerateRandomData();
	void GenerateRandomEvent();
	EventHeaderFT0 *GetEventHeaderPtr()	{return &fEventHeader;}
	EventDataFT0 *GetEventDataPtr()	{return fEventDataFT0;}
	void Print(bool doPrintData=false);

	const static size_t gSizeHeader = sizeof(struct EventHeaderFT0);
	const static size_t gSizeData = sizeof(struct EventDataFT0);
	const static int gStartDescriptor = 0x0000000f;
protected:
	uint64_t fNwords;
	uint64_t fOrbit;
	uint64_t fBC;
	bool fIsHalfWord;
	EventHeaderFT0 fEventHeader;
	EventDataFT0 fEventDataFT0[NCHANNELS_PM];
private:

	/////////////////////////////////////////////////
	ClassDef(DataBlockFT0,1);
};
#endif

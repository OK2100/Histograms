#include "DataBlockReaderFT0.h"

using namespace std;
using std::cout;
using std::endl;

ClassImp(DataBlockReaderFT0)

DataBlockReaderFT0::DataBlockReaderFT0(DataBlockFT0 *dataBlockFT0):
	fEventHeader(*dataBlockFT0->GetEventHeaderPtr()),
	fEventDataFT0(*dataBlockFT0->GetEventDataPtr())
{
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Initializating object DataBlockReaderFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";
	fPtrEventHeader = dataBlockFT0->GetEventHeaderPtr();
	fPtrEventData = dataBlockFT0->GetEventDataPtr();
	cout<<"\n/Initialization complete!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";

}
/*******************************************************************************************************************/

/*******************************************************************************************************************/
DataBlockReaderFT0::~DataBlockReaderFT0()	{
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Deleting object DataBlockReaderFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Deleting completed!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";
}

/*******************************************************************************************************************/

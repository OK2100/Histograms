#ifndef DataBlockFileReaderFT0_cxx
#define DataBlockFileReaderFT0_cxx
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <cstdio>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "DataBlockFT0.h"
#include "DataBlockReaderFT0.h"
using namespace std;
class DataBlockFileReaderFT0:public DataBlockReaderFT0
{
public:

//	DataBlockFileReaderFT0();
	DataBlockFileReaderFT0(char * srcFilepath, char * destFilepath, DataBlockFT0 *dataBlockFT0);

	virtual ~DataBlockFileReaderFT0();
	void InitFile();
	void SetFilepathSrc(char * filepath)	{fFilepathSrc = filepath;}
	void SetFilepathDest(char * filepath)	{fFilepathDest = filepath;}
	bool ReadNextEvent();
	void WriteNextEvent();
protected:
	char * fFilepathSrc;
	char * fFilepathDest;
	bool fIsFileSrcReady;
	bool fIsFileDestReady;
	bool fReadFlag;
	bool fSeekFlag;
	size_t fSizeObjectsData,fSizeObjectsHeader;
	FILE *fFileSrc;
	FILE *fFileDest;
	const static size_t fSizeHeader = sizeof(struct EventHeaderFT0);
	const static size_t fSizeData = sizeof(struct EventDataFT0);
	const static int fStartDescriptor = 0x0000000f;
private:

	/////////////////////////////////////////////////
	ClassDef(DataBlockFileReaderFT0,1);
};
#endif

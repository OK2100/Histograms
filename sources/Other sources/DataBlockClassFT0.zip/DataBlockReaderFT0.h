#ifndef DataBlockReaderFT0_cxx
#define DataBlockReaderFT0_cxx
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "DataBlockFT0.h"
class DataBlockReaderFT0
{
public:

	DataBlockReaderFT0(DataBlockFT0 *dataBlockFT0);
	virtual ~DataBlockReaderFT0();

protected:
	Int_t fNchannels;
	EventHeaderFT0 &fEventHeader;
	EventDataFT0 &fEventDataFT0;
	void *fPtrEventHeader;
	void *fPtrEventData;

private:

	/////////////////////////////////////////////////
	ClassDef(DataBlockReaderFT0,1);
};
#endif

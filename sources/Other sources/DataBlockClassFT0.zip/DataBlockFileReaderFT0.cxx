

#include "DataBlockFileReaderFT0.h"


ClassImp(DataBlockFileReaderFT0)
/*
DataBlockFileReaderFT0::DataBlockFileReaderFT0():RawDataReaderFT0(NULL)	{
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Initializating object DataBlockFileReaderFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";
	fCurrentPos=0;
	cout<<"\n/Initialization complete!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";

}*/
/*******************************************************************************************************************/
DataBlockFileReaderFT0::DataBlockFileReaderFT0(char * srcFilepath, char * destFilepath
										   , DataBlockFT0 *dataBlockFT0):
	DataBlockReaderFT0(dataBlockFT0),
	fIsFileSrcReady(false),fIsFileDestReady(false),fFileSrc(NULL),fFileDest(NULL),
	fFilepathSrc(srcFilepath),fFilepathDest(destFilepath)
{
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Initializating object DataBlockFileReaderFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";

	cout<<"\n/Initialization complete!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";

}
/*******************************************************************************************************************/
void DataBlockFileReaderFT0::InitFile()	{
	fFileSrc = fopen(fFilepathSrc,"rb");
	if(!fFileSrc)	{
		cout<<endl<<"Warning! Cannot open source file! Abort."<<endl;
	}
	fFileDest = fopen(fFilepathDest,"wb+");
	if(!fFileDest)	{
		cout<<endl<<"Warning! Cannot create destination file! Abort."<<endl;
	}

	if(fFileSrc) {
		//fseek(fFileSrc,0,SEEK_SET);
		fIsFileSrcReady = true;
	}
	if(fFileDest) {
		//fseek(fFileDest,0,SEEK_SET);
		fIsFileDestReady = true;
	}
}
/*******************************************************************************************************************/
bool DataBlockFileReaderFT0::ReadNextEvent()	{
	fSizeObjectsHeader = fread(fPtrEventHeader,fSizeHeader,1,fFileSrc);
	///Looking for header,by shifting bytes,
	///  if descriptor isn't correct
	while(fEventHeader.startDescriptor-fStartDescriptor)	{
		fseek(fFileSrc,1-fSizeHeader,SEEK_CUR);
		fSizeObjectsHeader = fread(fPtrEventHeader,fSizeHeader,1,fFileSrc);
		if(feof(fFileSrc)) return false;
	}
	if(!fSizeObjectsHeader)		return false;
	///
	fNchannels = 2*fEventHeader.Nwords;
	if(fNchannels)	fSizeObjectsData = fread(fPtrEventData,fSizeData,fNchannels,fFileSrc);
	if(!fSizeObjectsData) return false;
	return true;
}
/*******************************************************************************************************************/
void DataBlockFileReaderFT0::WriteNextEvent()	{
	fSizeObjectsHeader = fwrite(fPtrEventHeader,fSizeHeader,1,fFileDest);
	fSizeObjectsData = fwrite(fPtrEventData,fSizeData,2*fEventHeader.Nwords,fFileDest);
}
/*******************************************************************************************************************/
DataBlockFileReaderFT0::~DataBlockFileReaderFT0()	{
	cout<<"\n////////////////////////////////////////////////////////////////";
	cout<<"\n/Deleting object DataBlockFileReaderFT0...";
	cout<<"\n////////////////////////////////////////////////////////////////";
	if(fFileSrc)	fclose(fFileSrc);
	if(fFileDest)	fclose(fFileDest);
	cout<<"\n/Deleting completed!";
	cout<<"\n////////////////////////////////////////////////////////////////\n";
}

/*******************************************************************************************************************/
